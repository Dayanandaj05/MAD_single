# How to Make This App Work! (For Beginners)

Hi! If you want to run **just this specific app** (Hospital Doctor Directory), here is exactly what you need to do. It is like putting together a very simple puzzle!

## 🧩 The Puzzle Pieces You Need
There are **three** puzzle pieces in this folder:
1. `HospitalDirectoryActivity.kt` (The brain of the app)
2. `Doctor.kt` (A helper file that defines what a doctor is)
3. `activity_hospital_directory.xml` (The face/design of the app)

## 🛠️ Step-by-Step Instructions

**Step 1: Open Your Android Studio Project**
Create a new project in Android Studio or open an empty one.

**Step 2: Paste the "Brain" Files**
1. Copy `HospitalDirectoryActivity.kt` and `Doctor.kt` from this folder.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `java` ➔ `[your_package_name]`.
3. Paste both files right there!

**Step 3: Paste the "Face" File**
1. Copy `activity_hospital_directory.xml`.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `res` ➔ `layout`.
3. Paste the file there!

**Step 4: Tell Android Which Screen to Show First (Main Activity)**
1. Open your `AndroidManifest.xml` file (found in `app` ➔ `src` ➔ `main`).
2. Make sure you add `.HospitalDirectoryActivity` inside the `<application>` tag like this so it knows to start here:
```xml
<activity android:name=".HospitalDirectoryActivity" android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

**Step 5: Permissions? YES! ☎️**
Because this app needs to make phone calls, you have to ask for permission.
In your `AndroidManifest.xml` file, right **above** the `<application>` tag, paste this line:
```xml
<uses-permission android:name="android.permission.CALL_PHONE" />
```

**Step 6: Play!**
Click the green **Play** button at the top of Android Studio to run your app!
