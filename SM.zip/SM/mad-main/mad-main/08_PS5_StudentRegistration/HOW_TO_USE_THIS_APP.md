# How to Make This App Work! (For Beginners)

Hi! If you want to run **just this specific app** (Student Registration), here is exactly what you need to do. It is like putting together a very simple puzzle!

## 🧩 The Puzzle Pieces You Need
There are **four** puzzle pieces in this folder:
1. `StudentRegistrationActivity.kt` (The first screen's brain)
2. `StudentResultActivity.kt` (The second screen's brain)
3. `activity_student_registration.xml` (The first screen's design)
4. `activity_student_result.xml` (The second screen's design)

## 🛠️ Step-by-Step Instructions

**Step 1: Open Your Android Studio Project**
Create a new project in Android Studio or open an empty one.

**Step 2: Paste the "Brain" Files**
1. Copy `StudentRegistrationActivity.kt` and `StudentResultActivity.kt` from this folder.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `java` ➔ `[your_package_name]`.
3. Paste the files right there!

**Step 3: Paste the "Face" Files**
1. Copy `activity_student_registration.xml` and `activity_student_result.xml`.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `res` ➔ `layout`.
3. Paste the files there!

**Step 4: Tell Android About Your Screens**
1. Open your `AndroidManifest.xml` file (found in `app` ➔ `src` ➔ `main`).
2. Make sure you add both activities inside the `<application>` tag. Make `StudentRegistrationActivity` the main one so it starts there:
```xml
<activity android:name=".StudentResultActivity" />
<activity android:name=".StudentRegistrationActivity" android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

**Step 5: Permissions?**
Nope! You don't need to add any special permissions for this app.

**Step 6: Play!**
Click the green **Play** button at the top of Android Studio to run your app!
