# How to Make This App Work! (For Beginners)

Hi! If you want to run **just this specific app** (Mock Test 1: Menu & Music), here is exactly what you need to do. It is like putting together a very simple puzzle!

## 🧩 The Puzzle Pieces You Need
There are **six** puzzle pieces in this folder:
- **Brains (Kotlin Code):** `MainMenuActivity.kt`, `WhatsAppMessageActivity.kt`, and `MusicService.kt`
- **Faces (Designs):** `activity_menu_home.xml` and `activity_whatsapp_message.xml`
- **Menu:** `menu_main.xml`

## 🛠️ Step-by-Step Instructions

**Step 1: Open Your Android Studio Project**
Create a new project in Android Studio or open an empty one.

**Step 2: Paste the "Brain" Files**
1. Copy `MainMenuActivity.kt`, `WhatsAppMessageActivity.kt`, and `MusicService.kt` from this folder.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `java` ➔ `[your_package_name]`.
3. Paste all three files right there!

**Step 3: Paste the "Face" Files**
1. Copy `activity_menu_home.xml` and `activity_whatsapp_message.xml`.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `res` ➔ `layout`.
3. Paste them there!

**Step 4: Create & Paste the "Menu" File**
1. Under `app` ➔ `src` ➔ `main` ➔ `res`, create a new directory called `menu` if you don't have one.
2. Copy `menu_main.xml` into this new `menu` folder!

**Step 5: Tell Android About Your Screens & Service**
1. Open your `AndroidManifest.xml` file (found in `app` ➔ `src` ➔ `main`).
2. Make `MainMenuActivity` the main one so it starts there, and register the other screen and the music service. Paste this inside the `<application>` tag:
```xml
<activity android:name=".WhatsAppMessageActivity" />
<service android:name=".MusicService" />

<activity android:name=".MainMenuActivity" android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

**Step 6: Permissions? YES! 🎵**
Because this app plays background music and uses notifications, you have to ask for permission.
In your `AndroidManifest.xml` file, right **above** the `<application>` tag, paste these lines:
```xml
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
```

**Step 7: Play!**
Click the green **Play** button at the top of Android Studio to run your app!
