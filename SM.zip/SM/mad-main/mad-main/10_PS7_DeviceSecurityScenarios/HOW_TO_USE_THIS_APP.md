# How to Make This App Work! (For Beginners)

Hi! If you want to run **just this specific app** (Device Security Scenarios), here is exactly what you need to do. It is like putting together a very simple puzzle!

## 🧩 The Puzzle Pieces You Need
There are **two** puzzle pieces in this folder:
1. `SecurityScenariosActivity.kt` (The brain of the app)
2. `activity_security_scenarios.xml` (The face/design of the app)

## 🛠️ Step-by-Step Instructions

**Step 1: Open Your Android Studio Project**
Create a new project in Android Studio or open an empty one.

**Step 2: Paste the "Brain" File**
1. Copy `SecurityScenariosActivity.kt` from this folder.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `java` ➔ `[your_package_name]`.
3. Paste the file right there!

**Step 3: Paste the "Face" File**
1. Copy `activity_security_scenarios.xml`.
2. In Android Studio, go to `app` ➔ `src` ➔ `main` ➔ `res` ➔ `layout`.
3. Paste the file there!

**Step 4: Tell Android Which Screen to Show First (Main Activity)**
1. Open your `AndroidManifest.xml` file (found in `app` ➔ `src` ➔ `main`).
2. Make sure you add `.SecurityScenariosActivity` inside the `<application>` tag like this so it knows to start here:
```xml
<activity android:name=".SecurityScenariosActivity" android:exported="true">
    <intent-filter>
        <action android:name="android.intent.action.MAIN" />
        <category android:name="android.intent.category.LAUNCHER" />
    </intent-filter>
</activity>
```

**Step 5: Permissions?**
Nope! You don't need to add any special permissions for this app.

**Step 6: Play!**
Click the green **Play** button at the top of Android Studio to run your app!
