# 🎓 Android Lab Survival Guide

Welcome! This is your ultimate "Swiss Army Knife" for surviving Android practical exams. 
When time is ticking, **don't panic**. Use `Ctrl+F` (Windows) or `Cmd+F` (Mac) to search for keywords from your question paper and follow the exact step-by-step instructions.

---

## 🏗️ 0. PROJECT SETUP (Start Here!)
If you are starting your exam on a fresh PC, follow these exact steps to create a simple, working project:

1. **Open Android Studio** and click **New Project**.
2. Select **Empty Views Activity** (Do NOT choose "Empty Compose Activity"). Click Next.
3. **Name**: Type your app name (e.g., `LabExamApp`).
4. **Language**: Select **Kotlin**.
5. **Minimum SDK**: Select **API 21: Android 5.0 (Lollipop)** (Safest choice to avoid crazy modern Android permission errors).
6. **Build Configuration Language**: Kotlin DSL is fine (default).
7. Click **Finish**. Wait for the loading bar at the bottom to finish completely.

**Where does code go?**
- **Kotlin logic** goes in: `app -> java -> com.your.package... -> MainActivity.kt`
- **UI Design** goes in: `app -> res -> layout -> activity_main.xml`

---

## 🔎 How to Search This Guide
Press `Ctrl+F` (or `Cmd+F`), type a word from your exam question, and jump to the solution.

---

## ⏰ 1. Keywords: "Alarm", "Notification", "Time", "Delay", "Reminder"
*Example: "Create an app that takes a task name, and shows a notification after a set delay."*

### 📌 Files you need to open:
1. `fragment_notification.xml` (The Screen layout)
2. `NotificationReminderFragment.kt` (The button clicks)
3. `AlarmReceiver.kt` (Shows the actual notification)

### 👣 What to change:
**Step 1:** Open `fragment_notification.xml`. Change the `android:text` of the Title to whatever the question asks. Change the `android:hint` in the `EditText` boxes to match the inputs (e.g., changing "Enter Delay" to "Enter Minutes").
**Step 2:** Open `NotificationReminderFragment.kt`. 
- Look for `val titleText = editTitle.text.toString()`. Change variable names if you changed the IDs in XML.
- Look at the bottom where `alarmManager.setExact(...)` happens. By default, it does seconds. If they ask for minutes, change `(delaySeconds * 1000)` to `(delaySeconds * 60 * 1000)`.
**Step 3:** Open `AlarmReceiver.kt`. 
- This decides how the notification *looks*. Find `.setSmallIcon(...)` to change the icon. Find `.setContentTitle(myTitle)` to change the pop-up text.

---

## 📞 2. Keywords: "Call", "Dial", "Phone", "Number"
*Example: "Create an app. User types a number, presses Call, and the dialer opens."*

### 📌 Files you need to open:
1. `fragment_dialer.xml`
2. `DialerFragment.kt`

### 👣 What to change:
**Step 1:** Open `fragment_dialer.xml`. Change the button text and the hint on the EditText.
**Step 2:** Open `DialerFragment.kt`. 
- It uses `Intent.ACTION_DIAL`. This is SAFEST because it just opens the phone app.
- **SURVIVAL TIP:** `ACTION_DIAL` does *not* need permissions. But if the examiner says it must dial instantly, change `ACTION_DIAL` to `ACTION_CALL`. You MUST then open `AndroidManifest.xml` and add `<uses-permission android:name="android.permission.CALL_PHONE" />`.

---

## 📝 3. Keywords: "Grade", "Calculate", "Marks", "Student"
*Example: "Take a student name and 3 subjects. Show Grade A/B/C/Fail based on the average."*

### 📌 Files you need to open:
1. `fragment_grade.xml`
2. `GradeDescFragment.kt`

### 👣 What to change:
**Step 1:** Open `fragment_grade.xml`. Right now it only has one `<EditText>`. If the exam asks for 3 subjects, copy the `<EditText>` two more times. Give them new IDs like `editMarks1`, `editMarks2`, `editMarks3`.
**Step 2:** Open `GradeDescFragment.kt`.
- Go to `view.findViewById` and add the new ones: `val editMarks2 = view.findViewById<EditText>(R.id.editMarks2)`.
- Change the math from `val marksValue = marksText.toDouble()` to `val average = (marks1 + marks2 + marks3) / 3`.
- Scroll down to the `if (marksValue >= 90)` part. Change `90, 80, 70` to whatever rules the question paper gives you!

---

## 📡 4. Keywords: "Broadcast", "Send message", "Receiver", "Custom"
*Example: "Send a custom broadcast when a button is clicked. Catch it and show a Toast."*

### 📌 Files you need to open:
1. `fragment_message.xml`
2. `MessageBroadcastFragment.kt` (The Sender)
3. `MessageBroadcastReceiver.kt` (The Catcher)
4. `AndroidManifest.xml`

### 👣 What to change:
**Step 1:** Open `MessageBroadcastFragment.kt` (The Sender). 
- Inside the button click, create an Intent: `val myIntent = Intent("EXAM_CUSTOM_ACTION")`. **Change EXAM_CUSTOM_ACTION** to whatever the exam asks!
- Put your data: `myIntent.putExtra("MY_EXTRA_KEY", "Hello World!")`.
- Send it: `requireContext().sendBroadcast(myIntent)`.
**Step 2:** Open `MessageBroadcastReceiver.kt` (The Catcher).
- Adjust the `if` check: `if (intent.action == "EXAM_CUSTOM_ACTION")`.
- Get data: `val message = intent.getStringExtra("MY_EXTRA_KEY")`.
**Step 3:** Open `AndroidManifest.xml`.
- Find your receiver. Ensure the `<action android:name="EXAM_CUSTOM_ACTION" />` matches the string exactly!

---

## 💬 5. Keywords: "SMS", "Read message", "Incoming Message"
*Example: "Create an app that reads incoming SMS messages and displays the sender."*

### 📌 Files you need to open:
1. `SmsReceiver.kt`
2. `AndroidManifest.xml`

### 👣 What to change:
**Step 1:** Open `AndroidManifest.xml`.
- You MUST uncomment (remove `<!--`) the permissions: `<uses-permission android:name="android.permission.RECEIVE_SMS" />`.
- Scroll to the bottom and uncomment the `<receiver android:name=".SmsReceiver">` block.
**Step 2:** Open `SmsReceiver.kt`. 
- The complicated code extracting the message is already written for you. 
- Just change the `Toast.makeText` at the bottom to do what the question asks.

---

## 🧱 COMMON ANDROID CODE SNIPPETS
*Copy and paste these during your exam to save time!*

**Show a Pop-up Message (Toast):**
```kotlin
Toast.makeText(requireContext(), "Your message here", Toast.LENGTH_SHORT).show()
// If inside an Activity, replace 'requireContext()' with 'this'
```

**Find a View on the Screen:**
```kotlin
val myButton = view.findViewById<Button>(R.id.myButtonId)
val myText = view.findViewById<EditText>(R.id.myEditTextId)
```

**Get Text from User Input (EditText):**
```kotlin
val userInputText = myText.text.toString()
```

**Set Text to the Screen (TextView):**
```kotlin
val resultText = view.findViewById<TextView>(R.id.textResultId)
resultText.text = "The answer is: $userInputText"
```

**Open a New Screen (Activity):**
```kotlin
val intent = Intent(requireContext(), SecondActivity::class.java)
startActivity(intent)
```

**Button Click Listener:**
```kotlin
myButton.setOnClickListener {
    // Put code here that happens when clicked
}
```

**Simple Logging (Prints text in the 'Logcat' tab at the bottom):**
```kotlin
import android.util.Log
Log.d("EXAM_DEBUG", "My variable value is: $myVariable")
```

---

## 💥 COMMON CRASH FIXES
If your app crashes when you click run or press a button, check these first!

1. **"App keeps stopping" when I click a button! (NullPointerException)**
   - You probably wrote `findViewById(R.id.button1)` but the button in the XML file is named `android:id="@+id/btnSubmit"`. The names MUST EXACTLY MATCH.

2. **SecurityException or Permission Denial!**
   - Did you forget a permission in `AndroidManifest.xml`? 
   - Opening the dialer with `ACTION_CALL` replacing `ACTION_DIAL` needs `<uses-permission android:name="android.permission.CALL_PHONE" />`. Receiving texts needs `RECEIVE_SMS`.

3. **My Broadcast Receiver isn't catching anything!**
   - Did you spell the Action string exactly the same in all three places?
      1. SENDER Intent
      2. RECEIVER `if` statement
      3. MANIFEST `<intent-filter>`
   - Did you actually remember to type `sendBroadcast(intent)` after making the intent?

---

## 🐞 DEBUGGING TRICKS (When stuck!)
If the examiner is walking around and your app isn't working:
1. **Always test the button click first:** Put a simple `Toast.makeText(...)` right inside `setOnClickListener`. If the Toast shows, your button works. If not, your `findViewById` is probably wrong.
2. **Use Logs:** Open the `Logcat` tab at the very bottom of Android Studio. Filter by `EXAM_DEBUG` and use `Log.d("EXAM_DEBUG", "Got here!")` in your code to see exactly what line of code the app gets to before failing.
3. **Values are wrong?** If a calculation is showing `0` or outputting weird things, print the variable immediately after you read it: `Toast.makeText(context, "Read: " + marks, Toast.LENGTH_SHORT).show()`.

---

## 🛡️ EXAM SURVIVAL TIPS
- **Keep it Simple:** The examiner grades logic, not how pretty it looks. Stick to basic `LinearLayouts`. Forget colors or padding if time is short.
- **Cheat safely with Log or Toast:** When in doubt about whether a background process (like Alarm or SMS) is working, just spam a Toast to prove to the teacher that the event triggered!
- **ACTION_DIAL saves lives:** Always use `Intent.ACTION_DIAL` over `Intent.ACTION_CALL` unless specifically told not to. It avoids runtime permission headaches perfectly. 

Good luck! You've got this. 🎉
